# Processador MIPS

Implementação de um caminho de dados e unidade de controle para um processador MIPS. Utilizando a linguagem MIPS Assembly e o software Logisim.

Instruções implementadas: add, addi, sub, lw, sw, beq e jump.

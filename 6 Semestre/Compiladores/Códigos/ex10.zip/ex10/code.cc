string aluno;
string conceito;

write "========== SISTEMA ACADEMICO ==========";
write "Digite o nome do discente: ";
read aluno;

write "Informe o conceito obtido (A/B/C/D): ";
read conceito;

write "-----------------------------------";
write "RELATORIO FINAL";
write "Discente: ";
write aluno;
write "Conceito: ";
write conceito;
write "===================================";
write "Fim do programa";

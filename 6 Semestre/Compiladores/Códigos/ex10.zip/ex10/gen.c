/**
 * @file gen.c
 * @author Ivairton M. Santos - UFMT - Computacao
 * @brief Codificacao do modulo gerador de codigo
 * @version 0.2
 * @date 2022-02-23
 * 
 */

// Inclusao do cabecalho
#include "gen.h"

// Inclusao explicita de variaveis globais de outro contexto (symbols.h)
extern type_symbol_table_variables global_symbol_table_variables;
extern type_symbol_table_string symbol_table_string;
char output_file_name[MAX_CHAR];
FILE *output_file;

/**
 * @brief Funcao que gera codigo de montagem para SOMA
 * 
 */
void genAdd() {
    printf("pop rax\n");
    printf("pop rbx\n");
    printf("add rax,rbx\n");
    printf("push rax\n");
}

/**
 * @brief Funcao que gera codigo de montagem para SUBTRACAO
 * 
 */
void genSub() {
    printf("pop rbx\n");
    printf("pop rax\n");
    printf("sub rax,rbx\n");
    printf("push rax\n");
}

/**
 * @brief Funcao que gera codigo de montagem para MULTIPLICACAO
 * 
 */
void genMult() {
    printf("pop rax\n");
    printf("pop rbx\n");
    printf("imult rax,rbx\n");
    printf("push rax\n");
}

/**
 * @brief Funcao que gera codigo de montagem para DIVISAO
 * 
 */
void genDiv() {
    printf("pop rbx\n");
    printf("pop rax\n");
    printf("idiv rax,rbx\n");
    printf("push rax\n");
}

// Gera codigo de montagem para armazenamento de NUMERAL
void genNum(char num_string[MAX_TOKEN]) {
    printf("mov rax,%s\n", num_string);
    printf("push rax\n");
}

/**
 * @brief Funcao que gera um preambulo
 * 
 */
void gen_preambule(void) {
    fprintf(output_file, ";UFMT-Compiladores\n");
    fprintf(output_file, ";Prof. Ivairton\n");
    fprintf(output_file, ";Procedimento para geracao do executavel apos compilacao (em Linux):\n");
    fprintf(output_file, ";(1) compilacao do Assembly com nasm: $ nasm -f elf64 <nome_do_arquivo>\n");
    fprintf(output_file, ";(2) likedicao: $ ld -m elf_x86_64 <nome_arquivo_objeto>\n\n");
    fprintf(output_file, "extern printf\n");
    fprintf(output_file, "extern scanf\n");
}

//gera codigo da secao de dados
void gen_data_section(void) {
    //secao .data
    fprintf(output_file, "fmt_input_str    db \"%%255s\", 0\n");
    fprintf(output_file, "fmt_output_str   db \"%%s\", 10, 0\n\n");
    fprintf(output_file, "section .data\n");
    fprintf(output_file, "fmt_input_int    db \"%%d\", 0\n");
    fprintf(output_file, "fmt_output_int   db \"%%d\", 10, 0\n");
    fprintf(output_file, "fmt_input_float  db \"%%lf\", 0\n");
    fprintf(output_file, "fmt_output_float db \"%%.3f\", 10, 0\n");
    fprintf(output_file, "fmt_input_char   db \"%%c\", 0\n");
    fprintf(output_file, "fmt_output_char  db \"%%c\", 10, 0\n");


    // Strings constantes
    int n = symbol_table_string.n_strings;
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "%s db \"%s\", 0\n", symbol_table_string.string[i].name,symbol_table_string.string[i].value);
    }

    // Seção .bss para variáveis
    fprintf(output_file, "\nsection .bss\n");
    n = global_symbol_table_variables.n_variables;
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "%s ", global_symbol_table_variables.variable[i].name);
        switch(global_symbol_table_variables.variable[i].type) {
            case CHAR:  fprintf(output_file, "resb 1\n"); break;  // 1 byte
            case STRING: fprintf(output_file, "resb 300\n"); break; // 300 bytes
            case INT:    fprintf(output_file, "resd 1\n"); break;  // 4 bytes
            case FLOAT:  fprintf(output_file, "resq 1\n"); break;  // 8 bytes
            default:     fprintf(output_file, "; Tipo nao reconhecido\n"); break;
        }
    }
}

/**
 * @brief Funcao que gera a marcacao do inicio da secao de codigo
 * 
 */
void gen_preambule_code(void) {
    fprintf(output_file, "\nsection .text\n");
    fprintf(output_file, "global main\n");
    fprintf(output_file, "main:\n");
}

/**
 * @brief Funcao que encerra o codigo inserindo comandos de fechamento
 * 
 */
void gen_epilog_code(void) {
    fprintf(output_file, "\n;encerra programa\n");
    fprintf(output_file, "mov ebx,0\n");
    fprintf(output_file, "mov eax,1\n");
    fprintf(output_file, "int 0x80\n");
}


//Gerador de codigo para READ
void gen_read(char *lexeme_of_id, int tipo_dado) {
    switch(tipo_dado) {
        case CHAR:
            fprintf(output_file, "\n\t; read char\n");
            fprintf(output_file, "\tlea rdi, [fmt_input_char]\n");
            fprintf(output_file, "\tlea rsi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall scanf\n");
            break;

        case STRING:
            fprintf(output_file, "\n\t; read string\n");
            fprintf(output_file, "\tlea rdi, [fmt_input_str]\n");
            fprintf(output_file, "\tlea rsi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall scanf\n");
            break;

        case INT:
            fprintf(output_file, "\n\t; Read int\n");
            fprintf(output_file, "\tlea rdi, [fmt_input_int]\n");
            fprintf(output_file, "\tlea rsi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall scanf\n");
            break;

        case FLOAT:
            fprintf(output_file, "\n\t; read float\n");
            fprintf(output_file, "\tlea rdi, [fmt_input_float]\n");
            fprintf(output_file, "\tlea rsi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall scanf\n");
            break;

        default:
            fprintf(output_file, "; Tipo nao reconhecido para comando READ\n");
            break;
    }
}

//Gerador de codigo para WRITE
void gen_write(char *lexeme_of_id, int tipo_dado) {
    switch(tipo_dado) {
        case CHAR:
            fprintf(output_file, "\n\t; Write char\n");
            fprintf(output_file, "\tlea rdi, [fmt_output_char]\n");
            fprintf(output_file, "\tmov sil, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall printf\n");
            break;

        case STRING:
            fprintf(output_file, "\n\t; Write string\n");
            fprintf(output_file, "\tlea rdi, [fmt_output_str]\n");
            fprintf(output_file, "\tlea rsi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall printf\n");
            break;

        case INT:
            fprintf(output_file, "\n\t; Write int\n");
            fprintf(output_file, "\tlea rdi, [fmt_output_int]\n");
            fprintf(output_file, "\tmov esi, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\txor eax, eax\n");
            fprintf(output_file, "\tcall printf\n");
            break;

        case FLOAT:
            fprintf(output_file, "\n\t; Write float\n");
            fprintf(output_file, "\tlea rdi, [fmt_output_float]\n");
            fprintf(output_file, "\tmovq xmm0, [%s]\n", lexeme_of_id);
            fprintf(output_file, "\tmov rax, 1\n");  // 1 registro XMM usado
            fprintf(output_file, "\tcall printf\n");
            break;

        default:
            fprintf(output_file, "; Tipo nao reconhecido para comando WRITE\n");
            break;
    }
}
int valor;

write "Informe um valor:";
read valor;

if (1 + 1)
begin
    write "Impressao interna ao IF!\n";
end
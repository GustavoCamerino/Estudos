int a;
int b;
read a;
write a;
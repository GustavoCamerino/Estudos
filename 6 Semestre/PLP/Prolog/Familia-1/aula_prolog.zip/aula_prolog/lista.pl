/******************************************************************************************************************************************
    Paradigmas de Linguagens de programacao
    Prof. Robson
    Aluno: Gabriel Neves Silveria

    Exemplo de utilizacao de lista no PROLOG.
    Esse arquivo contem codigos simples e comentarios explicando como programar em PROLOG e como usar o interpretador "wsipl"

    * Ignorar os warnings, pois as duas variaveis realmente nao estao sendo muito utilizadas.

******************************************************************************************************************************************/


/* LISTA: */
% Lista eh igual em outras linguagens
cons(X,Y,[X|Y]).
membro(X,[X|C]).
membro(X,[Y|C]):-membro(X,C).


/*
    Exemplo 1 no interpretador:
        - [X|Y]=[vou,para,casa,comer]
        X=vou, -> Recebe a cabeca
        Y=[para,casa,comer] -> Recebe calda
        Une os elementos

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Exemplo 2 no interpretador:
        - [X,Y] = [vou,comer]
        X=vou, -> Recebe primeiro elemento
        Y=comer -> Recebe segundo elemento
        Une os elemtentos

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Logo:
        - Usa "|": A primeira variavel primeiro elemento recebe a cabeça e a segunda variavel a calda toda
        - Usa ",": Cada Variavel recebe o elemento especifico em ordem. Assim, se tiver mais elementos do que variaveis, da erro.


    Exemplo 3:
        Na linguagem:
            - cons(X,Y,[X|Y]).

        exemplo de consulta no interpretador:
            - cons(a,[b,c],X).
            Retorna: [a,b,c]

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Adaptacao para verificar se X eh cabeca ou calda de uma lista:
        cons(X,Y,[X|Y]).
        membro(X,[X|C]). -> Primeiro Testa se X eh cabeca da lista
        membro(X,[Y|C]):-membro(X,C). -> Depois testa se X eh calda da lista
*/


/* CONCATENACAO: */

conc([], L, L).
conc([X,L1],L2[X|L3]):-conc(L1,L2,L3). % Regra de concatenacao

/*
    Eh possivel concatenar duas listas usando o comando:
        - conc(L1,L2,Retorno).


    Tem tres casos:
        1 - Se a primeira lista eh vazia, retorna apenas a segunda lista -> conc([], L1, L1).
        2 - Se a segunda lista eh vazia, retorna apenas a primeira lista
        3 - Se as duas nao sao vazias, retorna uma nova lista, concatenando na ordem da esquerda pra direita

    Exemplos de uso de concatenacao:
    Concatena normal:
        - conc([a,b,c],[1,2,3],L). -> L se torna uma lista da concatenacao entre [a,b,c] e [1,2,3], L=[a,b,c,1,2,3]

    Todas as derivacoes possiveis de listas (ao contrario):
        - conc(L1,L2,[a,b,c]). -> retorna todas as derivacoes possiveis com a lista [a,b,c]
*/


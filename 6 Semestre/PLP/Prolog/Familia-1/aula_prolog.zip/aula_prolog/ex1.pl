% Comentario de unica linha em Prolog
/*
    Comentario de multiplas linhas prolog
*/


/******************************************************************************************************************************************
    Paradigmas de Linguagens de programacao
    Prof. Robson
    Aluno: Gabriel Neves Silveria

    Primeiro exemplo de utilizacao do PROLOG.
    Esse arquivo contem codigos simples e comentarios explicando como programar em PROLOG e como usar o interpretador "wsipl"

******************************************************************************************************************************************/


/*
    Comandos basicos prolog (swipl):
        halt. -> fecha o interpretador
        consult('nome do arquivo'). ->
        listing. -> mostra os fatos e regras carregados
        help -> mostra ajuda.
        write('texto') -> escreve um texto.

*/

/*
    IMPORTANTE: Todos os comandos, do PROLOG e do interprador devem ser terminados com ponto "."
*/

/* OBJETOS: */
% Base de conhecimento:
% progenitor eh um objeto
% Se esse objeto da seguinte forma: progenitor(maria, jose) -> maria eh progenitora de jose
progenitor(maria, jose).
progenitor(joao, jose).
progenitor(joao, ana).
progenitor(jose, julia).
progenitor(jose, iris).
progenitor(iris, jorge).

% Adicionando mais objetos na base de conhecimento (sexo)
masculino(joao).
masculino(jose).
masculino(jorge).
feminino(maria).
feminino(ana).
feminino(julia).
feminino(iris).


/* REGRAS: */
/*
    % Criando regras em PROLOG:
    % simbolo ':-' se le como 'se'
    % Se le assim: Se "Y" eh progenitor de "X", entao "X" eh filho de "Y".
    % Logo eh possivel consultar, em vez de "progenitor(nome1,nome2)", usar "filho(nome1,nome2)".
    filho(X,Y):-progenitor(Y,X).
*/

filho(X,Y):-progenitor(Y,X),masculino(X). % Criando regra para "filho" (sexo masculino)
filha(X,Y):-progenitor(Y,X),feminino(X). % Criando regra para "filha" (sexo feminino)
mae(X,Y):-progenitor(X,Y),feminino(X). % Criando regra para "pai" (sexo masculino)
pai(X,Y):-progenitor(X,Y),masculino(X). % Criando regra para "mae" (sexo feminino)
avo(X,Y):-progenitor(X,Z),progenitor(Z,Y),masculino(X). % Criando regra para "avo" (sexo masculino)

% Regra para antepassado (RECURSIVA)
% 2 possibilidades de regras:
antepassado(X,Y):-progenitor(X,Y). % antepassado direto -> X eh antepassado de Y?
antepassado(X,Y):-progenitor(X,Z),antepassado(Z,Y). % antepassado indireto (tem alguem no meio) -> X eh antepassado de Y e Y eh antepassado de Z?

/*
    Exemplo 1 de Consulta usando regra:
        - filho(X,jose).
    Processamento da Linguagem:
    X=X
    Y=jose
    filho(X,jose):-progenitor(jose,X).
    X=julia -> Achou uma opcao
    filho(julia,jose):-progenitor(jose,julia). -> Eh verdadeiro (comparacao de objetos).

    Tudo verdadeiro:
    Retorna "julia"

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Exemplo 2 de Consulta usando regra:
        - avo(X1,Y1). -> "X" eh avo de "Y"
    Processamento da linguagem:
    X=X1
    Y=Y1
    avo(X1,Y1):-progenitor(X1,Z),progenitor(Z,Y1),masculino(X1).
    X1=joao
    Z=jose
    progenitor(joao,jose) -> Verdadeiro
    Y1=julia
    progenitor(jose, julia) -> Verdadeiro
    masculino(joao) -> Verdadeiro

    Tudo verdadeiro = OK, retorna:
    X1=joao
    Z=jose

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Exemplo 3 de Consulta usando regra:
        - antepassado(jose,jorge). -> "jose" eh antepassado de "jorge"


    * Usa a primeira Regra de antepassado:
    - antepassado(X,Y):-progenitor(X,Y).
    X=jose
    Y=jorge

    * Usa a segunda Regra de antepassado:
    antepassado(jose,jorge):-progenitor(jose,Z),antepassado(Z,jorge).
    progenitor(jose,iris).
    Z=iris

    antepassado(josege,jorge) -> Verdadeiro
    antepassado(iris,jorge)
    X=iris
    Y=jorge
    antepassado(iris,jorge) -> Verdadeiro

    Como tudo eh verdadeiro, esse antepassado eh avo

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Exemplo 4 de Consulta usando regra:
    - antepassado(maria,X). -> "maria" eh antepassado de quem? (Busca em arvore utilizando logica)

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Exemplo 5 de Consulta usando regra:
    - antepassado(X,iris). -> quem sao o(s) antepassado(s) de iris? (Busca em arvore utilizando logica)

*/


/*
    Em uma consulta:
        - Para obter mais opcoes de resposta basta usar o simbolo ";" (eh interpretado como um "OR").
        - Para encerrar as respostas basta usar o simbolo "."
*/


/*
    Eh possivel consutlar se uma informacao eh verdadeira ou falsa na base de conhecimento.
    Para isso, nesse exemplo, basta escrever:
        - progenitor(nome1, nome2).

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    Outra forma de consultar, eh com a utilizacao de variaveis:
        - progenitor(X, nome).

    Aqui "X" eh uma variavel. Essa consulta vai buscar qual eh o progenitor de "nome". Vai ser retornado "X = nome_progenitor", sendo o progenitor de "nome".

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Outra forma de verificar eh:
        - progenitor(joao,X), progenitor(X,Neto).

    "X" e "Neto" sao variaveis.
    Ele vai fazer isso:
        X=jose (substitui) -> verdadeiro,progenitor(jose,Neto).
        Neto = julia -> Verdadeiro para ambos

    Se usar o comando ";" ele faz um backtracking e mostra o resultado (de novo?)

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    Usando esse exemplo, eh possivel ver se existe um progenitor em comum:
        - progenitor(X, jose), progenitor(X, jose) -> substitui "X" por um progenitor em comum de jose

*/


/*
    Outra forma de consulta eh com o "=":
        - progenitor(maria,jose)=progenitor(maria,jose). -> retorna "true"

    Assim, eh possivel ver se um objeto eh igual a outro.

    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

    Outra forma de fazer a mesma coisa com variaveis eh:
        - progenitor(maria,jose)=progenitor(maria,X). -> retorna "true"

    A linguagem vai substituir a variavel "X" por jose e vai retornar true.
*/


/*
    Outra forma de consultar a base de conhecimento completa eh:
        - progenitor(X, Y).

    Isso vai retornar todos os objetos progenitor
*/


import bpy
import random

# --- Limpar a cena existente ---
bpy.ops.wm.read_factory_settings(use_empty=True) # Começa com uma cena limpa

# --- Configurações ---
num_asteroids = 10
animation_frames = 250
start_frame = 1
end_frame = animation_frames

# --- 1. Criar a Nave (exemplo simples) ---
bpy.ops.mesh.primitive_uv_sphere_add(radius=0.5, enter_editmode=False, align='WORLD', location=(0, 0, 0))
nave = bpy.context.object
nave.name = "MinhaNave"
nave.location = (0, 0, -5) # Posição inicial da nave

# Adicionar um modificador de subdivisão para suavizar
bpy.ops.object.modifier_add(type='SUBSURF')
bpy.context.object.modifiers["Subdivision"].levels = 1
bpy.context.object.modifiers["Subdivision"].render_levels = 2
bpy.ops.object.shade_smooth()

# --- 2. Criar e Animar Asteroides ---
for i in range(num_asteroids):
    # Criar um asteroide base
    bpy.ops.mesh.primitive_uv_sphere_add(radius=random.uniform(0.5, 2.0), location=(random.uniform(-20, 20), random.uniform(-20, 20), random.uniform(-20, 20)))
    asteroid = bpy.context.object
    asteroid.name = f"Asteroide_{i:02d}"

    # Modificador Displace para irregularidade
    bpy.ops.object.modifier_add(type='DISPLACE')
    displace_mod = asteroid.modifiers["Displace"]
    
    # Adicionar textura Clouds
    new_texture = bpy.data.textures.new(name=f"AsteroidTex_{i:02d}", type='CLOUDS')
    displace_mod.texture = new_texture
    displace_mod.strength = random.uniform(0.3, 0.8) # Força da deformação

    bpy.ops.object.shade_smooth() # Suavizar o asteroide

    # Animar o asteroide
    start_pos = asteroid.location.copy()
    end_pos = (random.uniform(-30, 30), random.uniform(-30, 30), random.uniform(-30, 30))
    
    # Keyframe inicial
    asteroid.location = start_pos
    asteroid.keyframe_insert(data_path="location", frame=start_frame)

    # Keyframe final
    asteroid.location = end_pos
    asteroid.keyframe_insert(data_path="location", frame=end_frame)
    
    # Animar rotação (opcional)
    rotation_axis = (random.random(), random.random(), random.random())
    rotation_amount = random.uniform(0, 2 * 3.14159 * 2) # Rotaciona até 2 voltas completas
    
    asteroid.rotation_euler = (0, 0, 0)
    asteroid.keyframe_insert(data_path="rotation_euler", frame=start_frame)
    
    # Calculate end rotation (example: rotate around Z axis)
    asteroid.rotation_euler.z += rotation_amount
    asteroid.keyframe_insert(data_path="rotation_euler", frame=end_frame)


# --- 3. Ajustar a Câmera ---
# Remover câmera padrão se existir e criar uma nova para controle
if 'Camera' in bpy.data.objects:
    bpy.data.objects.remove(bpy.data.objects['Camera'], do_unlink=True)

bpy.ops.object.camera_add(location=(0, -15, 5))
camera = bpy.context.object
camera.name = "MinhaCamera"

# Apontar a câmera para a nave (ou para o centro da cena)
look_at_target = nave.location # Olhar para a nave
# look_at_target = (0, 0, 0) # Olhar para o centro da cena

# Calcular a rotação para a câmera olhar para o alvo
direction = look_at_target - camera.location
rot_quat = direction.to_track_quat('-Z', 'Y') # Aponta o eixo -Z da câmera para a direção
camera.rotation_euler = rot_quat.to_euler()

# Definir a câmera como a câmera ativa da cena
bpy.context.scene.camera = camera

# Ajustar foco da lente (FOV)
camera.data.lens = 35 # Um valor de lente comum para perspectiva

# --- Configurar Linha do Tempo ---
bpy.context.scene.frame_start = start_frame
bpy.context.scene.frame_end = end_frame
bpy.context.scene.render.fps = 24 # 24 frames por segundo


# Adicione esta linha no final do seu script para salvar
bpy.ops.wm.save_as_mainfile(filepath="/home/camerino/Área de Trabalho/Estudos/7-Semestre/Introdução à Computação Gráfica/Trab 1/minha_cena_espacial.blend")
// ex01.cc
// Programa imprime uma linha de texto.
#include <iostream> // biblioteca para I/O básico

// função principal
int main() {
   std::cout << "Bem vindo!\n"; // mostra mensagem no terminal
   std::cout << "C++ é uma linguagem de programação\n\texcelente!";

   return 0; // indica retorno com sucesso
} // fim da função main

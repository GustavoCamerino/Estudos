int y{5}; // declara a variável y
int* yPtr{nullptr}; // declara o ponteiro yPtr
yPtr = &y; 


#include <iostream>
using namespace std;

#define tam 3

int main () {
    // linder: Não fez nada do que foi pedido!    
    char x;
    char o;

    char jogar = 's';
    cout << "gostaria de jogar novamente (s/n): "<<
    cin >> jogar 

    while (jogar == 's' || jogar == 'S')
    for (int i = 0; i < 3; i++){
        for (int j = 0; j < 3; j++){
            cout << "digite a posicao que quer inserir: "<<
            cin >> i, j;
        }
        }
}

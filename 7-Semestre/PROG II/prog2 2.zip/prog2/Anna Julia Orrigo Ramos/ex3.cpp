#include <iostream>
#include <vector>
using namespace std;

// não fez nada do que foi pedido!

int main () {
    int tam
    cout << "digite a quantidade de numeros que voce quer inserir : "<<
    int num[tam];
    cout << "digite " << tam << " numeros: "<<
    cin >> num[tam];
    }

int media (int num){
    for (int i = 0; i < tam; i++){
    sum  += num[tam]}
    int media = (sum)/ 6;
    cout << "a media desses numeros é: "<< media << endl;
    return;
}

//int mediana (){
//    sort[num]
//   if (tam % 2 == 1){
//        mediana =
//    }else {
//        mediana = (num + num) / 2
//    }
//}

int moda (int num){
    count = 0
    for (int i; i < tam; i++){
        if (num == num){
            count++
        }else {
            count = 0
        }
    }
}





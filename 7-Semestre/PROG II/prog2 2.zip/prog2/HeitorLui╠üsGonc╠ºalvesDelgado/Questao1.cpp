#include <iostream>
#include <format>
//linder: nao fez nada!!

using namespace std;

int calcular
#include <iostream>
#include <format>
#include <vector> ///pode conter qualquer tamanho (de acordo com o usuário)

using namespace std;
//linder: não fez nada!

int calcular_media() {
///use a lista para calcular média (vector) achar entre os valores fornecidos
TAM = n
count = 0
MD = 0
  

}

int calcular_mediana() {
///use a lista para calcular mediana (vector) percorrer para ver o valor do meio



}

int calcular_moda() {
///use a lista para calcular moda (vector) achar oq mais aparece


///verificação se a empate e imprimir todos os valores

}

int main() { 
///Chamar as funções para teste


}
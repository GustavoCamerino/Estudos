#include <iostream>
#include <format>
#include <vector>
#include <random>

//linder: nao fez nada!
using namespace std;

int main(){

    


    return 0;
}


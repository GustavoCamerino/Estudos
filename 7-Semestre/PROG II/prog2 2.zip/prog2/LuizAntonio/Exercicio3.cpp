/*
UFMT - Bacharelado em Ciencia da Computação
Programação de Computadores
Luiz Antonio Marquetti Girardi Junior
*/

#include <format>
#include <iostream>
#include <string> 
#include <vector>

//linder: nao tem logica o que foi feito!

double calcularMedia(){
    int aux{0};
    int resto{0};
    int contagem;
    while (numero > 0) //linder: numero??
    {
    resto = numero % 10;
    aux += resto;
    contagem++;
    }
    int media;
    media = aux/contagem

    std::cout<<"Sua Média calculada eh " << media << std::endl;





}
int calcularModa()
int aux{0};
int resto{0};
int contagem;

while (numero > 0){
    resto = numero % 10;
    aux += resto;
    contagem++;
}

int moda;







int calcularMediana()




int main(){
    int numero{}
    std::cout << "Informe um Número ao usuário: " << std::endl;
    std::cin>>numero;


    std::vector<int>lista;
    lista = numero


}
/*Julia Dantas Cassin
(2.0 pts) Escreva um programa que esme o valor da constante matemá ca e usando 
a fórmula abaixo. O número de termos da soma deve ser fornecido pelo usuário. Use 
o po long para o cálculo do fatorial. 
/*

//linder: em branco




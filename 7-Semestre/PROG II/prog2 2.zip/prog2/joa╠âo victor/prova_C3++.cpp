#include <iostream>
#include <math>

//linder:  errado.

int média(int arry{y}){
    media_total = arry{y}/7;
    
    return media_total;
}
int mediana(int arry{y}){
    

    return mediana_total(max; main); 
    
}
int moda(int arry{y}){
    if(y == y){
        contador = +1

    }

    
    
}
int main(){
    int x;
    int arry{7};
        
    cout::std << "seleciones alguns number";
    cin::std<< x ;


    for(y = 0; y >=7 ; y++){
        arry{y} = x;        

    }

    mat1 = média{arry{y}}; 
    mat2 = mediana{arry{y}};
    mat3 = moda{arry{y}};


    cout::std << "a media: "<< mat1 <<"a mediana: "<< mat2 << "o que esta na moda é: "<< mat3 <<std::endl;



}
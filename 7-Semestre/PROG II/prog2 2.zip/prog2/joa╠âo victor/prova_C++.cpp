#include <iostream>
#include <random>

//linder: nao faz o que foi pedido.

int somas (int n,int a){
    
    if (n != 0 && 1){
        return n*(a - 1); 
    } else {
        return n;

    } else {
        return 0;
    }

}

int main (){
    int x{1};
    int y;
    int z;
    

    cout::std << " digite um numero "  ;
    cout::std << " digite um number ajudante";

    cin:: std << y;
    cin:: std << z;

    somas (int y, int z);


    white(somas >= 3628800){
        resultado = x +( x / somas);

    }

    cout::std << resultado << std::endl;

    return 0;

}


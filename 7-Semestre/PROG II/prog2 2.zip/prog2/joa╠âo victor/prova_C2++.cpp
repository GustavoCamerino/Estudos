#include <iostream>

namespace::std;

//linder: nao funciona

int main(){

    int arry{2}{2};
    int n;
        
    cout::std << " escolha entre x ou o";
    cin::std << n ;

    if (n == 1){
        x = 1;

        return x;
    }

    if(n==0){
        o = 0;

    }

    for(i = 0; i>=2; i++){
        for (j = 0; j>=2; j++ ){
            if(x ==({i} == {j})){
                cout::std <<"o vencedor é "<< x << std::endl;
            } else{
                cout::std <<"o vencedor é "<< o << std::endl;
            }

            if(x ==({i} == {j++})){
                cout::std <<"o vencedor é "<< x << std::endl;
            } else{
                cout::std <<"o vencedor é "<< o << std::endl;
            }

            if(x ==({i++} == {j})){
                cout::std <<"o vencedor é "<< x << std::endl;
            } else{
                cout::std <<"o vencedor é "<< o << std::endl;

        }

    }


    return 0;




}

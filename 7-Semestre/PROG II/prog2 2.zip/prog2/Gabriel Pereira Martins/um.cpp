/* Escreva um programa que esme o valor da constante matemá ca e usando 
a fórmula abaixo. O número de termos da soma deve ser fornecido pelo usuário. Use 
o po long para o cálculo do fatorial. 
*/
#include <iostream>
#include <iomanip> //linder: nunca usamdo em aula
#include <cmath>

int main (){

    int num = 0;
    long double mumero = 1.0;

    std::cout << "quantos termos a somatoria tera ? ";
    std::cin >> num;

    for(int i = 0 ; i < num; i++){
        
        numeros =+ 1/((i + 1)^e-6); //linder: nao faz nenhum sentido
    }

    std::cout << "VALOR DA FORMULA APLICADA AO VALOR : ";
    std::cin >> numeros;
    

    return 0;
    
}
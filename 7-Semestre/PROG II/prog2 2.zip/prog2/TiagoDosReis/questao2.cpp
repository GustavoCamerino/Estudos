#include <iostream>
#include <array>
#include <string>

//linder: nao funciona, sem sentido.

string X, O;

char arr<1,9>;

int jogador_um, jogador_dois;

int criacao_matriz (char x, char y) {

   for (int x; x < 0; x++ ){
    x < 3

    for (int y; y < 0; y++) {
        y < 3;
    }
}


}

int verificar_movimento() { 



}

int main () {


cout << "Jogador 1: Digite em qual posição você quer: " << endl;
cout >> jogador_um;

cout << "Jogador 2: Digite em qual posição você quer: " << endl;
cout >> jogador_dois;

for (int x; x < 0; x++ ){
    x < 3
// tentativa de criação de matriz 3x3 com for -- n vai da certo
    for (int y; y < 0; y++) {
        y < 3;
    }
}

return 0;

}
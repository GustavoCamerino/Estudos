#include <iostream>
#include <vector>
//linder: nao funciona, sem sentido

using namespace std;

float Vector();

float calculando_media (Vector{}) {

    float resultado_media = Vector()
    float media = 
    return resultado_media;

}

float calculando_mediana (Vector{}) {

    float resultado_mediana = Vector()
    float mediana = 
    return resultado_media;

}

float calculando_moda (Vector{}) {

    float resultado_moda = Vector();
    float moda
    return resultado_moda;

}

float sequencia_de_valores = Vector{};


int main () {

    cout << "Digite uma sequencia de valor: " << endl;
    cin << sequencia_de_valores;

return 0;

}
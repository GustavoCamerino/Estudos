#include <iostream>
//linder: nao funciona, sem sentido.
using namespace std;

long valor_fatorial;
int valor_digitado;

for (valor_fatorial; valor_fatorial > 0) {
    valor_fatorial++;
}

int main {

cout << "Número de termos da soma: " << endl;
cin >> valor_digitado;

cout << "e = 1 + 1/2! + 1/2! + 1/3 + ..." << 1/valor_fatorial! << endl; 

return 0;


}
